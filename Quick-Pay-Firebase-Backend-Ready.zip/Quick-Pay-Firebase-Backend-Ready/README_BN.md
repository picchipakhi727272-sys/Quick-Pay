Quick Pay Firebase Backend-ready files

1. Replace the existing MainActivity.java with the included file.
2. Keep the existing app/build.gradle Firebase dependencies already configured.
3. Deploy firestore.rules from Firebase Console > Firestore Database > Rules.
4. Firebase Authentication > Sign-in method > Phone must stay Enabled.
5. The app now uses Phone OTP for login/registration, stores the profile in Firestore, sends Add Money requests to depositRequests, stores transaction requests in transactions, and sends Group Chat messages as PENDING. Only APPROVED chat messages are read by users.

Important: admin approval/balance changes must be done by a trusted server/admin backend. The mobile client is not allowed by these rules to change balances or approve messages.
