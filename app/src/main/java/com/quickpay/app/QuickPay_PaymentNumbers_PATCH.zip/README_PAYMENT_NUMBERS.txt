শুধু এই দুইটি ফাইল GitHub-এ replace করুন:
1) app/src/main/java/com/quickpay/app/MainActivity.java
2) firestore.rules
অন্য কোনো ফাইল বদলাবেন না।
