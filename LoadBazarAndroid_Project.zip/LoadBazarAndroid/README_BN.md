# LoadBazar Android APK

এই project-এ LoadBazar-এর Login, Register এবং Home UI Android WebView-এর ভিতরে প্যাক করা আছে।

## APK বানানো
GitHub Actions workflow-টি `Build LoadBazar APK` নামে আছে। GitHub-এ project push করার পর Actions থেকে run করলে `LoadBazar-debug-apk` artifact পাওয়া যাবে।

এটি UI/demo APK; বাস্তব recharge/payment/backend এখনো সংযুক্ত নয়।
